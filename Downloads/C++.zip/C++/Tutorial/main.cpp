#include <iostream>

using namespace std;

int main()
{
    float v;
    float u;
    float m;
    float v2u2;
    float v2;
    float u2;
    float w;
    float w2;
    float kmh;
    {
        /*PLease Upvote and don't forget to suggest improvements and features for this code*/

        cout<<"Enter Mass of object:";
        cin>>m;
        cout<<"Enter Initial velocity(if not given enter 0):";
        cin>>u;
        cout<<"Enter Final velocity(if not given enter 0):";
        cin>>v;
        cout<<"If velocities are in km/h,Press 1; else Press 2;";
        cin>>kmh;
        if(kmh==1)
        {
            v=v*5/18;
            u=u*5/18;
        }
        v2=v*v;
        u2=u*u;
        if(v>0&&u>0)
        {
            v2u2=v2-u2;
            w=m*v2u2;
        }
        if(v==0)
        {
            w=m*u2;
        }
        if(u==0)
        {
            w=m*v2;
        }
        w2=w/2;
        cout<<"Energy = "<<w2;
    }
    return 0;
}

